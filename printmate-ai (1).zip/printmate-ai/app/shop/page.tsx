import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ShopClient from '@/components/ShopClient';
import { getProducts } from '@/lib/products';
import { CATEGORY_LABELS, type ProductCategory } from '@/lib/types';

const VALID_CATEGORIES = new Set(Object.keys(CATEGORY_LABELS));

export default async function ShopPage({
  searchParams,
}: {
  searchParams: { category?: string };
}) {
  const products = await getProducts();
  const requested = searchParams.category;
  const initialCategory: ProductCategory | 'all' =
    requested && VALID_CATEGORIES.has(requested)
      ? (requested as ProductCategory)
      : 'all';

  return (
    <>
      <Navbar />
      <main>
        <ShopClient products={products} initialCategory={initialCategory} />
      </main>
      <Footer />
    </>
  );
}
